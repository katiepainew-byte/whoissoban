import { Link } from 'react-router';
import { trpc } from '@/providers/trpc';
import { ArrowLeft, Calendar, BookOpen } from 'lucide-react';

export default function BlogList() {
  const { data: blogs, isLoading } = trpc.blog.list.useQuery({ publishedOnly: true });

  return (
    <div style={{ minHeight: '100vh', background: '#050A0F' }}>
      {/* Header */}
      <div style={{ position: 'relative', zIndex: 10, padding: '40px clamp(24px, 5vw, 80px)', borderBottom: '1px solid rgba(237, 232, 228, 0.08)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20 }}>
          <Link
            to="/"
            style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#7A8B6F', textDecoration: 'none', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 13, letterSpacing: '2px', textTransform: 'uppercase', transition: 'color 0.3s' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
            onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
          >
            <ArrowLeft size={16} />
            Back to Home
          </Link>
          <nav style={{ display: 'flex', gap: 32 }}>
            {[
              { label: 'Home', to: '/' },
              { label: 'Blogs', to: '/blogs' },
              { label: 'Research', to: '/research' },
              { label: 'Admin', to: '/admin' },
            ].map(item => (
              <Link
                key={item.to}
                to={item.to}
                style={{
                  color: item.to === '/blogs' ? '#30B0D0' : '#D4C5B0',
                  textDecoration: 'none',
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: 11,
                  letterSpacing: '2px',
                  textTransform: 'uppercase',
                  transition: 'color 0.3s',
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 10, maxWidth: 1200, margin: '0 auto', padding: '80px clamp(24px, 5vw, 80px)' }}>
        <div style={{ marginBottom: 60 }}>
          <span style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 10, fontWeight: 700, letterSpacing: '3px', textTransform: 'uppercase', color: '#30B0D0', marginBottom: 16 }}>
            KNOWLEDGE / 004
          </span>
          <h1 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 'clamp(2.5rem, 6vw, 4.5rem)', fontWeight: 500, color: '#EDE8E4', lineHeight: 1.1, margin: 0 }}>
            Blog
          </h1>
          <p style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 15, color: '#D4C5B0', lineHeight: 2, maxWidth: 600, marginTop: 20 }}>
            Thoughts on cybersecurity, technology, entrepreneurship, and the digital landscape.
          </p>
        </div>

        {isLoading ? (
          <div style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14 }}>Loading blogs...</div>
        ) : !blogs?.length ? (
          <div style={{ textAlign: 'center', padding: '80px 0' }}>
            <BookOpen size={48} style={{ color: '#1A2332', margin: '0 auto 20px' }} />
            <p style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 15 }}>No blogs published yet. Check back soon!</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: 32 }}>
            {blogs.map(blog => (
              <Link
                key={blog.id}
                to={`/blogs/${blog.slug}`}
                style={{ textDecoration: 'none', display: 'block' }}
              >
                <div
                  style={{
                    borderRadius: 2,
                    overflow: 'hidden',
                    background: 'rgba(10, 22, 40, 0.5)',
                    border: '1px solid rgba(237, 232, 228, 0.06)',
                    transition: 'transform 0.4s ease, box-shadow 0.4s ease',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.transform = 'translateY(-4px)';
                    e.currentTarget.style.boxShadow = '0 8px 32px rgba(48, 176, 208, 0.1)';
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  {blog.coverImage && (
                    <div style={{ width: '100%', aspectRatio: '16/9', overflow: 'hidden' }}>
                      <img
                        src={blog.coverImage}
                        alt={blog.title}
                        style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.6s ease' }}
                        onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.05)')}
                        onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
                      />
                    </div>
                  )}
                  <div style={{ padding: '24px 28px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                      <Calendar size={12} style={{ color: '#7A8B6F' }} />
                      <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, color: '#7A8B6F', letterSpacing: '1px' }}>
                        {new Date(blog.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                      </span>
                    </div>
                    <h2 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 'clamp(1.2rem, 2vw, 1.5rem)', fontWeight: 500, color: '#EDE8E4', lineHeight: 1.3, margin: '0 0 12px 0' }}>
                      {blog.title}
                    </h2>
                    {blog.excerpt && (
                      <p style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14, color: '#D4C5B0', lineHeight: 1.7, margin: 0, display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                        {blog.excerpt}
                      </p>
                    )}
                    <span style={{ display: 'inline-block', marginTop: 16, fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase', color: '#30B0D0' }}>
                      Read More
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
