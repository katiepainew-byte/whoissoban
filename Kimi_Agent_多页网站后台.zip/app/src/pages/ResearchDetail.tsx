import { useParams, Link } from 'react-router';
import { trpc } from '@/providers/trpc';
import { ArrowLeft, Calendar, Clock, FileText, ExternalLink } from 'lucide-react';

export default function ResearchDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { data: paper, isLoading } = trpc.research.getBySlug.useQuery(
    { slug: slug ?? '' },
    { enabled: !!slug }
  );

  if (isLoading) {
    return (
      <div style={{ minHeight: '100vh', background: '#050A0F', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14 }}>Loading...</div>
      </div>
    );
  }

  if (!paper) {
    return (
      <div style={{ minHeight: '100vh', background: '#050A0F', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 20 }}>
        <p style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 18 }}>Research paper not found</p>
        <Link to="/research" style={{ color: '#30B0D0', textDecoration: 'none', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14 }}>
          Back to Research
        </Link>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: '#050A0F' }}>
      {/* Header */}
      <div style={{ position: 'relative', zIndex: 10, padding: '40px clamp(24px, 5vw, 80px)', borderBottom: '1px solid rgba(237, 232, 228, 0.08)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20 }}>
          <Link
            to="/research"
            style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#7A8B6F', textDecoration: 'none', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 13, letterSpacing: '2px', textTransform: 'uppercase', transition: 'color 0.3s' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
            onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
          >
            <ArrowLeft size={16} />
            All Papers
          </Link>
          <nav style={{ display: 'flex', gap: 32 }}>
            {[
              { label: 'Home', to: '/' },
              { label: 'Blogs', to: '/blogs' },
              { label: 'Research', to: '/research' },
              { label: 'Admin', to: '/admin' },
            ].map(item => (
              <Link
                key={item.to}
                to={item.to}
                style={{
                  color: item.to === '/research' ? '#30B0D0' : '#D4C5B0',
                  textDecoration: 'none',
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: 11,
                  letterSpacing: '2px',
                  textTransform: 'uppercase',
                  transition: 'color 0.3s',
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Hero Image */}
      {paper.coverImage && (
        <div style={{ position: 'relative', width: '100%', height: '45vh', minHeight: 280, overflow: 'hidden' }}>
          <img src={paper.coverImage} alt={paper.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(5,10,15,0.3), rgba(5,10,15,0.95))' }} />
        </div>
      )}

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 10, maxWidth: 900, margin: paper.coverImage ? '-80px auto 0' : '60px auto 0', padding: '0 clamp(24px, 5vw, 80px) 120px' }}>
        <span style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 10, fontWeight: 700, letterSpacing: '3px', textTransform: 'uppercase', color: '#30B0D0', marginBottom: 20 }}>
          RESEARCH PAPER
        </span>

        <h1 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 'clamp(2rem, 5vw, 3.2rem)', fontWeight: 500, color: '#EDE8E4', lineHeight: 1.15, margin: '0 0 24px 0' }}>
          {paper.title}
        </h1>

        <div style={{ display: 'flex', alignItems: 'center', gap: 24, marginBottom: 40, paddingBottom: 32, borderBottom: '1px solid rgba(237, 232, 228, 0.08)', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Calendar size={14} style={{ color: '#7A8B6F' }} />
            <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 12, color: '#7A8B6F' }}>
              {new Date(paper.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Clock size={14} style={{ color: '#7A8B6F' }} />
            <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 12, color: '#7A8B6F' }}>
              {Math.ceil(paper.content.length / 1000)} min read
            </span>
          </div>
          {paper.pdfUrl && (
            <a
              href={paper.pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                color: '#30B0D0',
                textDecoration: 'none',
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: 12,
                letterSpacing: '1px',
                padding: '6px 16px',
                border: '1px solid #30B0D0',
                borderRadius: 999,
                transition: 'all 0.3s',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = '#30B0D0';
                e.currentTarget.style.color = '#050A0F';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#30B0D0';
              }}
            >
              <FileText size={14} />
              View PDF
              <ExternalLink size={12} />
            </a>
          )}
        </div>

        {/* Abstract */}
        <div style={{ background: 'rgba(10, 22, 40, 0.5)', border: '1px solid rgba(48, 176, 208, 0.15)', borderRadius: 2, padding: '28px 32px', marginBottom: 48 }}>
          <h2 style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 700, letterSpacing: '3px', textTransform: 'uppercase', color: '#30B0D0', margin: '0 0 16px 0' }}>
            Abstract
          </h2>
          <p style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 15, color: '#D4C5B0', lineHeight: 2, margin: 0, fontStyle: 'italic' }}>
            {paper.abstract}
          </p>
        </div>

        {/* Full Content */}
        <div
          style={{
            fontFamily: "'Noto Serif SC', serif",
            fontSize: 16,
            color: '#D4C5B0',
            lineHeight: 2,
          }}
          dangerouslySetInnerHTML={{ __html: paper.content.replace(/\n/g, '<br/>') }}
        />
      </div>
    </div>
  );
}
