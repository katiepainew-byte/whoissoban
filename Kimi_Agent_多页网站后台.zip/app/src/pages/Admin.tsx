import { useState } from 'react';
import { Link } from 'react-router';
import { useAuth } from '@/hooks/useAuth';
import { trpc } from '@/providers/trpc';
import {
  ArrowLeft,
  Plus,
  Pencil,
  Trash2,
  Eye,
  EyeOff,
  BookOpen,
  FileText,
  LogOut,
  X,
  Save,
  AlertCircle,
} from 'lucide-react';

function generateSlug(title: string) {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

type TabType = 'blogs' | 'research';
type ModalType = 'blog' | 'research' | null;

interface FormData {
  id?: number;
  title: string;
  slug: string;
  excerpt: string;
  abstract: string;
  content: string;
  coverImage: string;
  pdfUrl: string;
  published: boolean;
}

const emptyBlogForm: FormData = {
  title: '',
  slug: '',
  excerpt: '',
  abstract: '',
  content: '',
  coverImage: '',
  pdfUrl: '',
  published: false,
};

const emptyResearchForm: FormData = {
  title: '',
  slug: '',
  excerpt: '',
  abstract: '',
  content: '',
  coverImage: '',
  pdfUrl: '',
  published: false,
};

export default function Admin() {
  const { user, isAuthenticated, isLoading: authLoading, logout } = useAuth({ redirectOnUnauthenticated: true });
  const [activeTab, setActiveTab] = useState<TabType>('blogs');
  const [modalOpen, setModalOpen] = useState<ModalType>(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState<FormData>(emptyBlogForm);
  const [error, setError] = useState('');

  const utils = trpc.useUtils();

  const { data: blogs, isLoading: blogsLoading } = trpc.blog.list.useQuery(
    { publishedOnly: false },
    { enabled: isAuthenticated }
  );
  const { data: papers, isLoading: papersLoading } = trpc.research.list.useQuery(
    { publishedOnly: false },
    { enabled: isAuthenticated }
  );

  const createBlog = trpc.blog.create.useMutation({
    onSuccess: () => {
      utils.blog.list.invalidate();
      closeModal();
    },
    onError: (e) => setError(e.message),
  });
  const updateBlog = trpc.blog.update.useMutation({
    onSuccess: () => {
      utils.blog.list.invalidate();
      closeModal();
    },
    onError: (e) => setError(e.message),
  });
  const deleteBlog = trpc.blog.delete.useMutation({
    onSuccess: () => utils.blog.list.invalidate(),
  });
  const toggleBlogPublish = trpc.blog.togglePublish.useMutation({
    onSuccess: () => utils.blog.list.invalidate(),
  });

  const createResearch = trpc.research.create.useMutation({
    onSuccess: () => {
      utils.research.list.invalidate();
      closeModal();
    },
    onError: (e) => setError(e.message),
  });
  const updateResearch = trpc.research.update.useMutation({
    onSuccess: () => {
      utils.research.list.invalidate();
      closeModal();
    },
    onError: (e) => setError(e.message),
  });
  const deleteResearch = trpc.research.delete.useMutation({
    onSuccess: () => utils.research.list.invalidate(),
  });
  const toggleResearchPublish = trpc.research.togglePublish.useMutation({
    onSuccess: () => utils.research.list.invalidate(),
  });

  function closeModal() {
    setModalOpen(null);
    setEditMode(false);
    setFormData(emptyBlogForm);
    setError('');
  }

  function openCreateModal(type: ModalType) {
    setModalOpen(type);
    setEditMode(false);
    setFormData(type === 'blog' ? { ...emptyBlogForm } : { ...emptyResearchForm });
    setError('');
  }

  function openEditModal(type: ModalType, item: any) {
    setModalOpen(type);
    setEditMode(true);
    setFormData({
      id: item.id,
      title: item.title,
      slug: item.slug,
      excerpt: item.excerpt ?? '',
      abstract: item.abstract ?? '',
      content: item.content,
      coverImage: item.coverImage ?? '',
      pdfUrl: item.pdfUrl ?? '',
      published: item.published,
    });
    setError('');
  }

  function handleSubmit() {
    setError('');
    if (!formData.title.trim()) {
      setError('Title is required');
      return;
    }
    if (!formData.content.trim()) {
      setError('Content is required');
      return;
    }

    const slug = formData.slug.trim() || generateSlug(formData.title);

    if (modalOpen === 'blog') {
      if (editMode && formData.id) {
        updateBlog.mutate({
          id: formData.id,
          title: formData.title,
          slug,
          excerpt: formData.excerpt || undefined,
          content: formData.content,
          coverImage: formData.coverImage || undefined,
          published: formData.published,
        });
      } else {
        createBlog.mutate({
          title: formData.title,
          slug,
          excerpt: formData.excerpt || undefined,
          content: formData.content,
          coverImage: formData.coverImage || undefined,
          published: formData.published,
        });
      }
    } else if (modalOpen === 'research') {
      if (!formData.abstract.trim()) {
        setError('Abstract is required for research papers');
        return;
      }
      if (editMode && formData.id) {
        updateResearch.mutate({
          id: formData.id,
          title: formData.title,
          slug,
          abstract: formData.abstract,
          content: formData.content,
          pdfUrl: formData.pdfUrl || undefined,
          coverImage: formData.coverImage || undefined,
          published: formData.published,
        });
      } else {
        createResearch.mutate({
          title: formData.title,
          slug,
          abstract: formData.abstract,
          content: formData.content,
          pdfUrl: formData.pdfUrl || undefined,
          coverImage: formData.coverImage || undefined,
          published: formData.published,
        });
      }
    }
  }

  if (authLoading) {
    return (
      <div style={{ minHeight: '100vh', background: '#050A0F', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14 }}>Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect
  }

  return (
    <div style={{ minHeight: '100vh', background: '#050A0F' }}>
      {/* Header */}
      <div style={{ position: 'relative', zIndex: 10, padding: '24px clamp(24px, 5vw, 80px)', borderBottom: '1px solid rgba(237, 232, 228, 0.08)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#7A8B6F', textDecoration: 'none', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 13, letterSpacing: '2px', textTransform: 'uppercase', transition: 'color 0.3s' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
              onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}>
              <ArrowLeft size={16} />
              Home
            </Link>
            <span style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 20, fontWeight: 500, color: '#EDE8E4' }}>Admin Dashboard</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 12, color: '#7A8B6F' }}>
              {user?.name ?? user?.email ?? 'Admin'}
            </span>
            <button
              onClick={logout}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: 'transparent',
                border: '1px solid rgba(237, 232, 228, 0.15)',
                color: '#7A8B6F',
                padding: '6px 14px',
                borderRadius: 999,
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: 11,
                letterSpacing: '1px',
                cursor: 'pointer',
                transition: 'all 0.3s',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = '#30B0D0';
                e.currentTarget.style.color = '#30B0D0';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'rgba(237, 232, 228, 0.15)';
                e.currentTarget.style.color = '#7A8B6F';
              }}
            >
              <LogOut size={12} />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '40px clamp(24px, 5vw, 80px) 80px' }}>
        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 40, borderBottom: '1px solid rgba(237, 232, 228, 0.08)' }}>
          {([
            { key: 'blogs' as TabType, label: 'Blogs', icon: BookOpen, count: blogs?.length ?? 0 },
            { key: 'research' as TabType, label: 'Research Papers', icon: FileText, count: papers?.length ?? 0 },
          ]).map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                padding: '12px 24px',
                background: activeTab === tab.key ? 'rgba(48, 176, 208, 0.1)' : 'transparent',
                border: 'none',
                borderBottom: `2px solid ${activeTab === tab.key ? '#30B0D0' : 'transparent'}`,
                color: activeTab === tab.key ? '#30B0D0' : '#7A8B6F',
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: 13,
                fontWeight: activeTab === tab.key ? 600 : 400,
                cursor: 'pointer',
                transition: 'all 0.3s',
                letterSpacing: '1px',
                textTransform: 'uppercase',
              }}
            >
              <tab.icon size={16} />
              {tab.label}
              <span style={{
                marginLeft: 4,
                fontSize: 11,
                background: activeTab === tab.key ? 'rgba(48, 176, 208, 0.2)' : 'rgba(26, 35, 50, 0.6)',
                padding: '2px 8px',
                borderRadius: 999,
              }}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Create Button */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 24 }}>
          <button
            onClick={() => openCreateModal(activeTab === 'blogs' ? 'blog' : 'research')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              background: '#30B0D0',
              border: 'none',
              color: '#050A0F',
              padding: '10px 24px',
              borderRadius: 999,
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: 12,
              fontWeight: 600,
              cursor: 'pointer',
              transition: 'all 0.3s',
              letterSpacing: '1px',
              textTransform: 'uppercase',
            }}
          >
            <Plus size={16} />
            Create {activeTab === 'blogs' ? 'Blog' : 'Paper'}
          </button>
        </div>

        {/* Items List */}
        {activeTab === 'blogs' ? (
          blogsLoading ? (
            <div style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14, padding: '40px 0' }}>Loading blogs...</div>
          ) : !blogs?.length ? (
            <div style={{ textAlign: 'center', padding: '60px 0' }}>
              <BookOpen size={40} style={{ color: '#1A2332', margin: '0 auto 16px' }} />
              <p style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14 }}>No blogs yet. Create your first blog!</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {blogs.map(blog => (
                <div
                  key={blog.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 16,
                    padding: '16px 20px',
                    borderRadius: 4,
                    background: 'rgba(10, 22, 40, 0.4)',
                    border: '1px solid rgba(237, 232, 228, 0.06)',
                    transition: 'all 0.3s',
                  }}
                >
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 4 }}>
                      <h3 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 15, fontWeight: 500, color: '#EDE8E4', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {blog.title}
                      </h3>
                      <span style={{
                        fontSize: 10,
                        padding: '2px 10px',
                        borderRadius: 999,
                        background: blog.published ? 'rgba(48, 176, 208, 0.15)' : 'rgba(26, 35, 50, 0.6)',
                        color: blog.published ? '#30B0D0' : '#7A8B6F',
                        fontFamily: "'Noto Sans SC', sans-serif",
                        letterSpacing: '1px',
                        textTransform: 'uppercase',
                        whiteSpace: 'nowrap',
                      }}>
                        {blog.published ? 'Published' : 'Draft'}
                      </span>
                    </div>
                    <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, color: '#7A8B6F', letterSpacing: '1px' }}>
                      /blogs/{blog.slug} &middot; {new Date(blog.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <button
                      onClick={() => toggleBlogPublish.mutate({ id: blog.id })}
                      title={blog.published ? 'Unpublish' : 'Publish'}
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#7A8B6F',
                        cursor: 'pointer',
                        padding: 6,
                        borderRadius: 4,
                        transition: 'all 0.3s',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
                    >
                      {blog.published ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                    <button
                      onClick={() => openEditModal('blog', blog)}
                      title="Edit"
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#7A8B6F',
                        cursor: 'pointer',
                        padding: 6,
                        borderRadius: 4,
                        transition: 'all 0.3s',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      onClick={() => { if (confirm('Delete this blog?')) deleteBlog.mutate({ id: blog.id }); }}
                      title="Delete"
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#7A8B6F',
                        cursor: 'pointer',
                        padding: 6,
                        borderRadius: 4,
                        transition: 'all 0.3s',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#C85A5A')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          papersLoading ? (
            <div style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14, padding: '40px 0' }}>Loading research papers...</div>
          ) : !papers?.length ? (
            <div style={{ textAlign: 'center', padding: '60px 0' }}>
              <FileText size={40} style={{ color: '#1A2332', margin: '0 auto 16px' }} />
              <p style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14 }}>No research papers yet. Create your first paper!</p>
n            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {papers.map(paper => (
                <div
                  key={paper.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 16,
                    padding: '16px 20px',
                    borderRadius: 4,
                    background: 'rgba(10, 22, 40, 0.4)',
                    border: '1px solid rgba(237, 232, 228, 0.06)',
                    transition: 'all 0.3s',
                  }}
                >
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 4 }}>
                      <h3 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 15, fontWeight: 500, color: '#EDE8E4', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {paper.title}
                      </h3>
                      <span style={{
                        fontSize: 10,
                        padding: '2px 10px',
                        borderRadius: 999,
                        background: paper.published ? 'rgba(48, 176, 208, 0.15)' : 'rgba(26, 35, 50, 0.6)',
                        color: paper.published ? '#30B0D0' : '#7A8B6F',
                        fontFamily: "'Noto Sans SC', sans-serif",
                        letterSpacing: '1px',
                        textTransform: 'uppercase',
                        whiteSpace: 'nowrap',
                      }}>
                        {paper.published ? 'Published' : 'Draft'}
                      </span>
                    </div>
                    <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, color: '#7A8B6F', letterSpacing: '1px' }}>
                      /research/{paper.slug} &middot; {new Date(paper.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <button
                      onClick={() => toggleResearchPublish.mutate({ id: paper.id })}
                      title={paper.published ? 'Unpublish' : 'Publish'}
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#7A8B6F',
                        cursor: 'pointer',
                        padding: 6,
                        borderRadius: 4,
                        transition: 'all 0.3s',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
                    >
                      {paper.published ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                    <button
                      onClick={() => openEditModal('research', paper)}
                      title="Edit"
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#7A8B6F',
                        cursor: 'pointer',
                        padding: 6,
                        borderRadius: 4,
                        transition: 'all 0.3s',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      onClick={() => { if (confirm('Delete this research paper?')) deleteResearch.mutate({ id: paper.id }); }}
                      title="Delete"
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#7A8B6F',
                        cursor: 'pointer',
                        padding: 6,
                        borderRadius: 4,
                        transition: 'all 0.3s',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#C85A5A')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>

      {/* Modal */}
      {modalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 200,
            background: 'rgba(5, 10, 15, 0.85)',
            backdropFilter: 'blur(8px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
          }}
          onClick={(e) => { if (e.target === e.currentTarget) closeModal(); }}
        >
          <div
            style={{
              width: '100%',
              maxWidth: 720,
              maxHeight: '90vh',
              overflow: 'auto',
              background: '#0A1628',
              border: '1px solid rgba(237, 232, 228, 0.1)',
              borderRadius: 8,
              padding: '32px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
              <h2 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 22, fontWeight: 500, color: '#EDE8E4', margin: 0 }}>
                {editMode ? 'Edit' : 'Create'} {modalOpen === 'blog' ? 'Blog' : 'Research Paper'}
              </h2>
              <button
                onClick={closeModal}
                style={{ background: 'transparent', border: 'none', color: '#7A8B6F', cursor: 'pointer', padding: 4 }}
              >
                <X size={20} />
              </button>
            </div>

            {error && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '12px 16px', background: 'rgba(200, 90, 90, 0.1)', border: '1px solid rgba(200, 90, 90, 0.2)', borderRadius: 4, marginBottom: 20, color: '#C8966F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 13 }}>
                <AlertCircle size={16} />
                {error}
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <label style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: '2px', textTransform: 'uppercase', color: '#7A8B6F', marginBottom: 6 }}>
                  Title *
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={e => {
                    setFormData(prev => ({ ...prev, title: e.target.value }));
                    if (!editMode && !formData.slug) {
                      setFormData(prev => ({ ...prev, title: e.target.value, slug: generateSlug(e.target.value) }));
                    }
                  }}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    background: 'rgba(5, 10, 15, 0.6)',
                    border: '1px solid rgba(237, 232, 228, 0.1)',
                    borderRadius: 4,
                    color: '#EDE8E4',
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: 14,
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: '2px', textTransform: 'uppercase', color: '#7A8B6F', marginBottom: 6 }}>
                  Slug (auto-generated if empty)
                </label>
                <input
                  type="text"
                  value={formData.slug}
                  onChange={e => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    background: 'rgba(5, 10, 15, 0.6)',
                    border: '1px solid rgba(237, 232, 228, 0.1)',
                    borderRadius: 4,
                    color: '#EDE8E4',
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: 14,
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>

              {modalOpen === 'blog' && (
                <div>
                  <label style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: '2px', textTransform: 'uppercase', color: '#7A8B6F', marginBottom: 6 }}>
                    Excerpt
                  </label>
                  <textarea
                    value={formData.excerpt}
                    onChange={e => setFormData(prev => ({ ...prev, excerpt: e.target.value }))}
                    rows={2}
                    style={{
                      width: '100%',
                      padding: '10px 14px',
                      background: 'rgba(5, 10, 15, 0.6)',
                      border: '1px solid rgba(237, 232, 228, 0.1)',
                      borderRadius: 4,
                      color: '#EDE8E4',
                      fontFamily: "'Noto Sans SC', sans-serif",
                      fontSize: 14,
                      outline: 'none',
                      resize: 'vertical',
                      boxSizing: 'border-box',
                    }}
                  />
                </div>
              )}

              {modalOpen === 'research' && (
                <div>
                  <label style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: '2px', textTransform: 'uppercase', color: '#7A8B6F', marginBottom: 6 }}>
                    Abstract *
                  </label>
                  <textarea
                    value={formData.abstract}
                    onChange={e => setFormData(prev => ({ ...prev, abstract: e.target.value }))}
                    rows={3}
                    style={{
                      width: '100%',
                      padding: '10px 14px',
                      background: 'rgba(5, 10, 15, 0.6)',
                      border: '1px solid rgba(237, 232, 228, 0.1)',
                      borderRadius: 4,
                      color: '#EDE8E4',
                      fontFamily: "'Noto Sans SC', sans-serif",
                      fontSize: 14,
                      outline: 'none',
                      resize: 'vertical',
                      boxSizing: 'border-box',
                    }}
                  />
                </div>
              )}

              <div>
                <label style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: '2px', textTransform: 'uppercase', color: '#7A8B6F', marginBottom: 6 }}>
                  Content *
                </label>
                <textarea
                  value={formData.content}
                  onChange={e => setFormData(prev => ({ ...prev, content: e.target.value }))}
                  rows={10}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    background: 'rgba(5, 10, 15, 0.6)',
                    border: '1px solid rgba(237, 232, 228, 0.1)',
                    borderRadius: 4,
                    color: '#EDE8E4',
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: 14,
                    outline: 'none',
                    resize: 'vertical',
                    boxSizing: 'border-box',
                    lineHeight: 1.7,
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: '2px', textTransform: 'uppercase', color: '#7A8B6F', marginBottom: 6 }}>
                  Cover Image URL
                </label>
                <input
                  type="text"
                  value={formData.coverImage}
                  onChange={e => setFormData(prev => ({ ...prev, coverImage: e.target.value }))}
                  placeholder="https://example.com/image.jpg"
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    background: 'rgba(5, 10, 15, 0.6)',
                    border: '1px solid rgba(237, 232, 228, 0.1)',
                    borderRadius: 4,
                    color: '#EDE8E4',
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: 14,
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>

              {modalOpen === 'research' && (
                <div>
                  <label style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: '2px', textTransform: 'uppercase', color: '#7A8B6F', marginBottom: 6 }}>
                    PDF URL
                  </label>
                  <input
                    type="text"
                    value={formData.pdfUrl}
                    onChange={e => setFormData(prev => ({ ...prev, pdfUrl: e.target.value }))}
                    placeholder="https://example.com/paper.pdf"
                    style={{
                      width: '100%',
                      padding: '10px 14px',
                      background: 'rgba(5, 10, 15, 0.6)',
                      border: '1px solid rgba(237, 232, 228, 0.1)',
                      borderRadius: 4,
                      color: '#EDE8E4',
                      fontFamily: "'Noto Sans SC', sans-serif",
                      fontSize: 14,
                      outline: 'none',
                      boxSizing: 'border-box',
                    }}
                  />
                </div>
              )}

              <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={formData.published}
                  onChange={e => setFormData(prev => ({ ...prev, published: e.target.checked }))}
                  style={{ accentColor: '#30B0D0' }}
                />
                <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 13, color: '#D4C5B0' }}>
                  Publish immediately
                </span>
              </label>

              <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 8 }}>
                <button
                  onClick={closeModal}
                  style={{
                    padding: '10px 24px',
                    background: 'transparent',
                    border: '1px solid rgba(237, 232, 228, 0.15)',
                    color: '#7A8B6F',
                    borderRadius: 999,
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: 12,
                    cursor: 'pointer',
                    transition: 'all 0.3s',
                    letterSpacing: '1px',
                    textTransform: 'uppercase',
                  }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={createBlog.isPending || updateBlog.isPending || createResearch.isPending || updateResearch.isPending}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                    padding: '10px 28px',
                    background: '#30B0D0',
                    border: 'none',
                    color: '#050A0F',
                    borderRadius: 999,
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: 'pointer',
                    transition: 'all 0.3s',
                    letterSpacing: '1px',
                    textTransform: 'uppercase',
                    opacity: (createBlog.isPending || updateBlog.isPending || createResearch.isPending || updateResearch.isPending) ? 0.6 : 1,
                  }}
                >
                  <Save size={14} />
                  {editMode ? 'Update' : 'Create'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
