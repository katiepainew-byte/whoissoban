import { Link } from 'react-router';
import { trpc } from '@/providers/trpc';
import { ArrowLeft, Calendar, FileText } from 'lucide-react';

export default function ResearchList() {
  const { data: papers, isLoading } = trpc.research.list.useQuery({ publishedOnly: true });

  return (
    <div style={{ minHeight: '100vh', background: '#050A0F' }}>
      {/* Header */}
      <div style={{ position: 'relative', zIndex: 10, padding: '40px clamp(24px, 5vw, 80px)', borderBottom: '1px solid rgba(237, 232, 228, 0.08)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20 }}>
          <Link
            to="/"
            style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#7A8B6F', textDecoration: 'none', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 13, letterSpacing: '2px', textTransform: 'uppercase', transition: 'color 0.3s' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#30B0D0')}
            onMouseLeave={e => (e.currentTarget.style.color = '#7A8B6F')}
          >
            <ArrowLeft size={16} />
            Back to Home
          </Link>
          <nav style={{ display: 'flex', gap: 32 }}>
            {[
              { label: 'Home', to: '/' },
              { label: 'Blogs', to: '/blogs' },
              { label: 'Research', to: '/research' },
              { label: 'Admin', to: '/admin' },
            ].map(item => (
              <Link
                key={item.to}
                to={item.to}
                style={{
                  color: item.to === '/research' ? '#30B0D0' : '#D4C5B0',
                  textDecoration: 'none',
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: 11,
                  letterSpacing: '2px',
                  textTransform: 'uppercase',
                  transition: 'color 0.3s',
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 10, maxWidth: 1200, margin: '0 auto', padding: '80px clamp(24px, 5vw, 80px)' }}>
        <div style={{ marginBottom: 60 }}>
          <span style={{ display: 'block', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 10, fontWeight: 700, letterSpacing: '3px', textTransform: 'uppercase', color: '#30B0D0', marginBottom: 16 }}>
            PUBLICATIONS / 005
          </span>
          <h1 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 'clamp(2.5rem, 6vw, 4.5rem)', fontWeight: 500, color: '#EDE8E4', lineHeight: 1.1, margin: 0 }}>
            Research Papers
          </h1>
          <p style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 15, color: '#D4C5B0', lineHeight: 2, maxWidth: 600, marginTop: 20 }}>
            Academic and professional research on cybersecurity, religious literacy, geopolitics, and the intersection of technology and society.
          </p>
        </div>

        {isLoading ? (
          <div style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14 }}>Loading research papers...</div>
        ) : !papers?.length ? (
          <div style={{ textAlign: 'center', padding: '80px 0' }}>
            <FileText size={48} style={{ color: '#1A2332', margin: '0 auto 20px' }} />
            <p style={{ color: '#7A8B6F', fontFamily: "'Noto Sans SC', sans-serif", fontSize: 15 }}>No research papers published yet. Check back soon!</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            {papers.map(paper => (
              <Link
                key={paper.id}
                to={`/research/${paper.slug}`}
                style={{ textDecoration: 'none' }}
              >
                <div
                  style={{
                    display: 'flex',
                    gap: 32,
                    padding: '32px',
                    borderRadius: 2,
                    background: 'rgba(10, 22, 40, 0.3)',
                    border: '1px solid rgba(237, 232, 228, 0.06)',
                    transition: 'all 0.4s ease',
                    cursor: 'pointer',
                    flexWrap: 'wrap',
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.background = 'rgba(10, 22, 40, 0.6)';
                    e.currentTarget.style.borderColor = 'rgba(48, 176, 208, 0.2)';
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.background = 'rgba(10, 22, 40, 0.3)';
                    e.currentTarget.style.borderColor = 'rgba(237, 232, 228, 0.06)';
                  }}
                >
                  {paper.coverImage && (
                    <div style={{ width: 200, height: 260, flexShrink: 0, borderRadius: 2, overflow: 'hidden' }}>
                      <img src={paper.coverImage} alt={paper.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </div>
                  )}
                  <div style={{ flex: 1, minWidth: 250 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                      <Calendar size={12} style={{ color: '#7A8B6F' }} />
                      <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, color: '#7A8B6F', letterSpacing: '1px' }}>
                        {new Date(paper.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}
                      </span>
                    </div>
                    <h2 style={{ fontFamily: "'Noto Serif SC', serif", fontSize: 'clamp(1.3rem, 2.5vw, 1.8rem)', fontWeight: 500, color: '#EDE8E4', lineHeight: 1.3, margin: '0 0 16px 0' }}>
                      {paper.title}
                    </h2>
                    <p style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 14, color: '#D4C5B0', lineHeight: 1.8, margin: '0 0 20px 0', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                      {paper.abstract}
                    </p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                      <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase', color: '#30B0D0' }}>
                        Read Paper
                      </span>
                      {paper.pdfUrl && (
                        <span style={{ fontFamily: "'Noto Sans SC', sans-serif", fontSize: 11, letterSpacing: '1px', color: '#7A8B6F', background: 'rgba(26, 35, 50, 0.6)', padding: '4px 12px', borderRadius: 999 }}>
                          PDF Available
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
