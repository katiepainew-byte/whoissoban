export interface SiteConfig {
  language: string
  siteTitle: string
  siteDescription: string
}

export interface NavLink {
  label: string
  targetId: string
}

export interface NavigationConfig {
  brandMark: string
  links: NavLink[]
}

export interface HeroConfig {
  wordmarkText: string
  eyebrow: string
  titleLine1: string
  titleLine2: string
  descriptionLine1: string
  descriptionLine2: string
  ctaText: string
  ctaTargetId: string
}

export interface PhilosophyConfig {
  eyebrow: string
  title: string
  body: string
  rollingWords: string[]
}

export interface ProjectMeta {
  label: string
  value: string
}

export interface ProjectData {
  id: string
  title: string
  location: string
  year: string
  image: string
  subtitle: string
  meta: ProjectMeta[]
  paragraphs: string[]
}

export interface GalleryConfig {
  sectionLabel: string
  title: string
  projects: ProjectData[]
}

export interface MediumItem {
  cn: string
  en: string
  description: string
}

export interface MediumsConfig {
  sectionLabel: string
  items: MediumItem[]
}

export interface FooterEntry {
  text: string
  href?: string
}

export interface FooterColumn {
  heading: string
  entries: FooterEntry[]
}

export interface FooterConfig {
  visionText: string
  brandName: string
  columns: FooterColumn[]
  copyright: string
  videoPath: string
}

export interface ProjectDetailConfig {
  backLabel: string
}

export const siteConfig: SiteConfig = {
  language: "en",
  siteTitle: "Syed Soban Ali — Portfolio",
  siteDescription: "Syed Soban Ali — Entrepreneur, Cybersecurity Expert, CTO at CreatByte, Founder of Soban Groups & Technical Soban. Certified ethical hacker, educator, and digital architect.",
}

export const navigationConfig: NavigationConfig = {
  brandMark: "SS",
  links: [
    { label: "About", targetId: "philosophy" },
    { label: "Works", targetId: "gallery" },
    { label: "Expertise", targetId: "mediums" },
    { label: "Contact", targetId: "footer" },
  ],
}

export const heroConfig: HeroConfig = {
  wordmarkText: "SYED SOBAN ALI",
  eyebrow: "Entrepreneur / Cybersecurity Expert / CTO",
  titleLine1: "GUARDING THE",
  titleLine2: "DIGITAL FRONTIER",
  descriptionLine1: "Founder of Soban Groups & CTO at CreatByte.",
  descriptionLine2: "Ethical hacker, educator & digital architect building secure futures since age 13.",
  ctaText: "Explore My Work",
  ctaTargetId: "gallery",
}

export const philosophyConfig: PhilosophyConfig = {
  eyebrow: "PHILOSOPHY",
  title: "Driven by Purpose",
  body: "From a 13-year-old mobile repair entrepreneur to a certified cybersecurity professional leading CreatByte's technical vision. Building technology that empowers and secures.",
  rollingWords: ["SECURITY", "INNOVATE", "EDUCATE", "CREATE", "LEAD", "PROTECT"],
}

export const galleryConfig: GalleryConfig = {
  sectionLabel: "FEATURED WORKS / 001",
  title: "SELECTED VENTURES",
  projects: [
    {
      id: "creatbyte",
      title: "CreatByte",
      location: "India & Intl",
      year: "2024",
      image: "images/project-1.jpg",
      subtitle: "CTO & Security Officer — Building Secure Digital Futures",
      meta: [
        { label: "ROLE", value: "CTO & Security Officer" },
        { label: "SINCE", value: "January 2026" },
        { label: "SCOPE", value: "India & International" },
      ],
      paragraphs: [
        "Overseeing technical architecture, product design, and software security at CreatByte. Managing business execution with strategic vision and mission leadership across both CreatByte India and CreatByte International.",
        "Leading creative, technical, and logical operations since November 2024. Directing geo-data sharing operations and implementing comprehensive cybersecurity protocols across all CreatByte platforms and client infrastructures.",
        "Responsible for deploying enterprise security tools including Graylog, Acunetix, and Palo Alto firewalls. Managing all graphic design, video editing, client relationships, lead generation, and software development consultation.",
      ],
    },
    {
      id: "technical-soban",
      title: "Tech Soban",
      location: "YouTube",
      year: "2019",
      image: "images/project-2.jpg",
      subtitle: "Educating the Next Generation of Cybersecurity Professionals",
      meta: [
        { label: "ROLE", value: "Founder & Educator" },
        { label: "SINCE", value: "September 2019" },
        { label: "PLATFORM", value: "YouTube" },
      ],
      paragraphs: [
        "Founded Technical Soban, also known as Soban Trust, as an educational initiative to train students in ethical hacking, cybersecurity concepts, computer hardware, troubleshooting, and IT support.",
        "The channel serves as a comprehensive knowledge hub for aspiring security professionals, providing accessible education in complex technical domains including network defense, digital forensics, and penetration testing.",
        "Beyond education, Soban Trust operates as a charitable organization providing free IT support, account recovery services, mobile restoration, and cyber fraud prevention consulting to students and individuals who cannot afford professional assistance.",
      ],
    },
    {
      id: "soban-groups",
      title: "Soban Grp",
      location: "Nizamabad",
      year: "2024",
      image: "images/project-3.jpg",
      subtitle: "A Unified Vision for Technology, Media, and Industry",
      meta: [
        { label: "ROLE", value: "Founder" },
        { label: "SINCE", value: "December 2024" },
        { label: "SCOPE", value: "Parent Company" },
      ],
      paragraphs: [
        "Formed Soban Groups to unify digital marketing, cybersecurity consulting, IT support, and creative film ventures under a single parent entity with a unified strategic vision.",
        "Soban Groups serves as the holding company for CreatByte (India & International), Soban News, Soban Store, Soban Groups of Technology, Soban Groups of Industries, and Future Investment ventures.",
        "The group orchestrates strategic direction and resource allocation across all subsidiaries without direct service delivery — enabling each entity to focus on its core competency while benefiting from shared infrastructure and vision.",
      ],
    },
    {
      id: "game-dev",
      title: "Game Dev",
      location: "Unity",
      year: "2025",
      image: "images/project-4.jpg",
      subtitle: "From Modding to Unity — Engineering Interactive Experiences",
      meta: [
        { label: "ROLE", value: "Game Developer" },
        { label: "SINCE", value: "October 2016" },
        { label: "ENGINE", value: "Unity" },
      ],
      paragraphs: [
        "Leads game development processes using Unity, including the recreation of the classic Nokia Bounce game — a project that demonstrates both technical skill and nostalgic creative vision.",
        "Expertise spans game modding, scripting, and memory manipulation for titles including Free Fire, BGMI, and GTA 5. Deep understanding of cheat logic, exploit injection, and memory offsets in Rockstar games.",
        "Certified in Llama model AI applications through Scaler School of Technology, bringing artificial intelligence into modern game development workflows and exploring the intersection of AI and interactive entertainment.",
      ],
    },
  ],
}

export const mediumsConfig: MediumsConfig = {
  sectionLabel: "EXPERTISE / 003",
  items: [
    {
      cn: "CYBER",
      en: "CYBERSECURITY",
      description: "Certified in Ethical Hacking (EHE), Network Defense (NDE), and Digital Forensics (DFE). Deep knowledge of CISSP frameworks, bash scripting, Docker, Graylog, and Splunk.",
    },
    {
      cn: "TECH",
      en: "IT & SYSTEMS",
      description: "Hardware diagnostics, mobile restoration, OS installations, custom firmware, and full-stack troubleshooting from GPU assembly to motherboard circuits.",
    },
    {
      cn: "CODE",
      en: "DEVELOPMENT",
      description: "Python, Java, C, C++. Game modding for Free Fire, BGMI, GTA 5. Unity game development including the Nokia Bounce recreation project.",
    },
    {
      cn: "STRATEGY",
      en: "DIGITAL MARKETING",
      description: "SEO, AEO, GEO optimization. WordPress development, social media management, Meta Ads, and AI-powered workflows with ChatGPT.",
    },
    {
      cn: "CREATE",
      en: "CREATIVE MEDIA",
      description: "Film making, mobile cinematography, storyboarding. Video editing in Premiere Pro, DaVinci Resolve, After Effects. Graphic design across Adobe Suite and Affinity.",
    },
  ],
}

export const footerConfig: FooterConfig = {
  visionText: "From repairing mobile phones at age 13 to securing digital infrastructures across India and beyond — committed to altruism, education, and building technology that empowers. Free IT support, account recovery, and cyber fraud consulting for those who need it most.",
  brandName: "SOBAN ALI",
  columns: [
    {
      heading: "CONNECT",
      entries: [
        { text: "syedsobanali8@gmail.com", href: "mailto:syedsobanali8@gmail.com" },
        { text: "LinkedIn", href: "https://www.linkedin.com/in/syed-soban-ali-72191a225" },
      ],
    },
    {
      heading: "VENTURES",
      entries: [
        { text: "CreatByte India" },
        { text: "CreatByte International" },
        { text: "Soban Groups" },
        { text: "Technical Soban" },
      ],
    },
    {
      heading: "LOCATION",
      entries: [
        { text: "Nizamabad" },
        { text: "Telangana" },
        { text: "India" },
      ],
    },
  ],
  copyright: "2025 Syed Soban Ali. All rights reserved.",
  videoPath: "",
}

export const projectDetailConfig: ProjectDetailConfig = {
  backLabel: "Back",
}

export function getProjectById(id: string): ProjectData | undefined {
  return galleryConfig.projects.find((p) => p.id === id)
}
